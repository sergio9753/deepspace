#encoding:utf-8
module Deepspace	
	module GameCharacter
		ENEMYSTARSHIP=:enemystarship
		SPACESTATION=:spacestation
	end
end